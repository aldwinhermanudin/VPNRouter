#!/bin/bash
args0="echo"
args1="sample"
cmd=(${args0} ${args1})
${cmd[@]}
