#!/bin/bash

input="/opt/lux/last_connection_type.elytra"
file_in=$(cat ${input})

echo ${file_in}
