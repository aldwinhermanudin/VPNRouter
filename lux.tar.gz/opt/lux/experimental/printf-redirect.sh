#!/bin/bash

test_data="TesT"
printf ${test_data} > /media/sdcard0/lux/test.log
