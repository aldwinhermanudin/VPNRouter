#!/bin/bash
script_path="$( cd "$(/usr/bin/dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
path_to_utils=${script_path}/utils.sh

. ${path_to_utils} --source-only 

check_log(){
  log_size=$(/usr/bin/stat -c %s $1)

  if ((${log_size} > $2)); then
    echo_time "size is above max: ${log_size}"
    echo_time "deleting file"
    /bin/rm -f $1
  else
    echo_time "size is below max: ${log_size}"
  fi
}

check_log $ADD_SSH_RULE_LOG $MAX_LOG_SIZE
