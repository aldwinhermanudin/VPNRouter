#!/bin/bash

ret=0
if /usr/bin/nordvpn connect $1; then 
  echo "Connect $1 succeeded"
  ret=0
else
  echo "Connect $1 failed"
  ret=1
fi

sudo /opt/lux/add-ssh-rules.sh
exit ${ret}
