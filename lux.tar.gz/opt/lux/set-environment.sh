#!/bin/bash

export ADD_SSH_RULE_LOG=/media/sdcard0/logs/add-ssh-rules.log
export MAX_LOG_SIZE=$((5*1000*1000))
